#include <iostream>
#include <string>
#include <map>

// Phone book class
class PhoneBook {
private:
    std::map<std::string, std::string> contacts;

public:
    // Add a contact to the phone book
    void addContact(const std::string& name, const std::string& phoneNumber) {
        contacts[name] = phoneNumber;
        std::cout << "Contact added: " << name << " - " << phoneNumber << std::endl;
    }

    // Search for a contact by name
    void searchContact(const std::string& name) {
        std::map<std::string, std::string>::const_iterator it = contacts.find(name);
        if (it != contacts.end()) {
            std::cout << "Contact found: " << it->first << " - " << it->second << std::endl;
        } else {
            std::cout << "Contact not found: " << name << std::endl;
        }
    }

    // Delete a contact by name
    void deleteContact(const std::string& name) {
        std::map<std::string, std::string>::iterator it = contacts.find(name);
        if (it != contacts.end()) {
            contacts.erase(it);
            std::cout << "Contact deleted: " << name << std::endl;
        } else {
            std::cout << "Contact not found: " << name << std::endl;
        }
    }

    // Display all contacts in the phone book
    void displayContacts() {
        std::cout << "Phone Book Contacts:" << std::endl;
        for (std::map<std::string, std::string>::const_iterator it = contacts.begin(); it != contacts.end(); ++it) {
            std::cout << it->first << " - " << it->second << std::endl;
        }
    }
};

int main() {
    PhoneBook phoneBook;

    // Menu loop
    while (true) {
        std::cout << "Phone Book Application" << std::endl;
        std::cout << "1. Add Contact" << std::endl;
        std::cout << "2. Search Contact" << std::endl;
        std::cout << "3. Delete Contact" << std::endl;
        std::cout << "4. Display Contacts" << std::endl;
        std::cout << "5. Exit" << std::endl;
        std::cout << "Enter your choice: ";

        int choice;
        std::cin >> choice;

        switch (choice) {
            case 1: {
                std::string name, phoneNumber;
                std::cout << "Enter contact name: ";
                std::cin.ignore();
                std::getline(std::cin, name);
                std::cout << "Enter phone number: ";
                std::getline(std::cin, phoneNumber);
                phoneBook.addContact(name, phoneNumber);
                break;
            }
            case 2: {
                std::string name;
                std::cout << "Enter contact name to search: ";
                std::cin.ignore();
                std::getline(std::cin, name);
                phoneBook.searchContact(name);
                break;
            }
            case 3: {
                std::string name;
                std::cout << "Enter contact name to delete: ";
                std::cin.ignore();
                std::getline(std::cin, name);
                phoneBook.deleteContact(name);
                break;
            }
            case 4:
                phoneBook.displayContacts();
                break;
            case 5:
                std::cout << "Exiting Phone Book Application. Goodbye!" << std::endl;
                return 0;
            default:
                std::cout << "Invalid choice. Please try again." << std::endl;
        }

        std::cout << std::endl;
    }

    return 0;
}